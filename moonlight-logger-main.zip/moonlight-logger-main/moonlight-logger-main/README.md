<h1 align="center">
  <br>
  Moonlight Logger 🌙
  <br>
</h1>


---

## What is Moonlight Logger?

Moonlight Logger is a Discord token grabber for Windows. With Moonlight, you can easily generate payloads to steal Discord tokens, Chrome passwords, cookies,
and credit cards. The data will be sent to your Discord webhook.

## How to setup & build stubs using Moonlight Logger?

> To build Moonlight Logger, please follow the guide at [usage](info/USAGE.md).

## Moonlight Logger Features

- Gather information about the users system
- Gather information about the users IP address
- Steals the users Discord token
- Steal chrome passwords
- Steal chrome cookies
- Steal chrome credit cards

![image](https://user-images.githubusercontent.com/113278474/189518022-d5621213-117d-4cee-af27-a55e596509de.png)
![Capture](https://user-images.githubusercontent.com/113278474/189518024-456eda30-c558-4bec-8eb2-fef0b7e845c4.PNG)

## Disclaimer

Moonlight Logger was made for educational purposes only. I am not responsible for the misuse of Moonlight Logger. **Do not use this software for malicious purposes! 😉**
