<h1 align="center">
  <br>
  Moonlight Logger | Usage Guide🌙
  <br>
</h1>

---

# Chapter 1: Installing Moonlight Logger
* **Step 1**. Download the Github repository to your system

![image](https://user-images.githubusercontent.com/113278474/189515389-184927bd-1c8f-4ad0-ae07-82aef563b4a7.png)

* **Step 2**. Extract the zip archive of the repository

![image](https://user-images.githubusercontent.com/113278474/189515421-0d22e475-87e0-4543-9907-6331534aebb0.png)

* **Step 3**. Run `install.bat`

# Chapter 2: Building Payloads w/ Moonlight Logger

* **Step 1**. Run `build.bat`

![image](https://user-images.githubusercontent.com/113278474/189515502-21b6d8d8-4c46-4e3e-9767-0ce85cc1194e.png)

* **Step 2**. Enter your webhook, and build your stub! 😸

![image](https://user-images.githubusercontent.com/113278474/189515563-c5e99562-5199-4a47-91da-c138e3a6c43c.png)
